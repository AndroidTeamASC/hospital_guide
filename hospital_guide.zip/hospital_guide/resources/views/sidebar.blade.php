<ul class="sidebar navbar-nav">
      <li class="nav-item active">
        <a class="nav-link" href="/head/dashboard">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span>
        </a>
      </li>
		<li class="nav-item">
        <a class="nav-link" href="{{route('hospital.index')}}">
          <i class="fas fa-fw fa-table"></i>
          <span>Hospital</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="{{route('package.index')}}">
          <i class="fas fa-fw fa-table"></i>
          <span>Package</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="{{route('speciality.index')}}">
          <i class="fas fa-fw fa-table"></i>
          <span>Speciality</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="{{route('physician.index')}}">
          <i class="fas fa-fw fa-table"></i>
          <span>Physician</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="{{route('schedule.index')}}">
          <i class="fas fa-fw fa-table"></i>
          <span>Schedule</span></a>
      </li>



      
    </ul>
