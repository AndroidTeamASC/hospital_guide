
<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-md-12">
		<div class="add">
			<h1>Department </h1>
			<form action="<?php echo e(route('department.store')); ?>" method="post" enctype="multipart/form-data">
				<?php echo csrf_field(); ?>
				<div class="row mt-5">
					<div class="col-md-3 ">
					<label>Department Name</label>
				</div>
				<div class="col-md-5">
					<input type="text" name="name" class="form-control">
				</div>
				
				</div>
				
				<div class="row mt-5">
					<div class="col-md-3 ">
					<label>Website Link</label>
				</div>
				<div class="col-md-5">
					<input type="text" name="url" class="form-control">
				</div>
				
				</div>
				<div class="row mt-5">
					<div class="col-md-3 ">
					<label>Image</label>
				</div>
				<div class="col-md-5">
					<input type="file" name="image" class="form-control">
				</div>
				
				</div>
				
				
				<div class="col-md-3">
					<input type="submit" value="ADD">
				</div>
			</form>	
		</div>
		<div class="edit">
			<h1> Edit Department </h1>
			<form action="<?php echo e(route('department.update',1)); ?>" method="post" enctype="multipart/form-data">
				<?php echo csrf_field(); ?>
				<?php echo method_field('PUT'); ?>
				<input type="hidden" name="edit_id" id="edit_id">
				<div class="row mt-5">
					<div class="col-md-3 ">
					<label>Department Name</label>
				</div>
				<div class="col-md-5">
					<input type="text" name="edit_name" class="form-control" value="" id="edit_name">
				</div>
				
				</div>
				
				<div class="row mt-5">
					<div class="col-md-3 ">
					<label>Website Link</label>
				</div>
				<div class="col-md-5">
					<input type="text" name="edit_url" class="form-control" id="edit_url">
				</div>
				
				</div>
				<div class="row mt-5">
					<div class="col-md-3 ">
					<label>Image</label>
				</div>
				<div class="col-md-5">
					<input type="file" name="image" class="form-control">
					
				</div>
				<div class="col-md-4">
					<img src="" id="edit_image" width="150" height="150">
					<input type="hidden" name="old_image" id="edit_image_old">
				</div>
				
				</div>
				
				
				<div class="col-md-3">
					<input type="submit" value="ADD">
				</div>
			</form>	
		</div>

		

	<div class="col-md-8 offset-2 mt-5">

		<table class="table table-dark table-sm">
			<tr>
				<th>NO.</th>
				<th>Department Name</th>
				<th>Website Link</th>
				<th>Image</th>
				<th colspan="2">Action</th>
			</tr>
			<?php $i = 1; ?>
			<?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><?php echo e($i++); ?></td>
				<td><?php echo e($department->name); ?></td>
				<td><?php echo e($department->url); ?></td>
				<td><img src="<?php echo e($department->image); ?>" width="150" height="150"></td>
				<td>
					<a href="#" class="btn btn-secondary  edit_item " data-id="<?php echo e($department->id); ?>" data-name = "<?php echo e($department->name); ?>" data-url="<?php echo e($department->url); ?>" data-image="<?php echo e($department->image); ?>"  >Edit</a>
				</td>
				<td>	
                    <form action="<?php echo e(route('department.destroy',$department->id)); ?>" method="post">
                        <?php echo method_field('Delete'); ?>
                        <?php echo csrf_field(); ?>
                        <input type="submit" name="btnsubmit" value="Delete" class="btn btn-danger">
                     </form>
                </td>
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</table>
	</div>
		
	</div>
	
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

	<script type="text/javascript">
		
		$(document).ready(function(){
			$('.add').show();
			$('.edit').hide();
			$('.edit_item').click(function(){
				$('.edit').show();
				$('.add').hide();
				var id = $(this).data('id');
				var name = $(this).data('name');
				var url = $(this).data('url');
				var image = $(this).data('image');
				console.log(id,name,url,image);
				$('#edit_id').val(id);
				$('#edit_name').val(name);
				$('#edit_url').val(url);
				$('#edit_image').attr("src",image);
				$('#edit_image_old').val(image);
			})
		})
	</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backtemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lawofmyanmar\resources\views/department/index.blade.php ENDPATH**/ ?>