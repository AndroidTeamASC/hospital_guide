
<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-md-12">
		<div class="add">
			<h1>Speciality </h1>
			<?php if($errors->any()): ?>
			    <div class="alert alert-danger">
			        <ul>
			            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			                <li><?php echo e($error); ?></li>
			            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			        </ul>
			    </div>
			<?php endif; ?>
			<form action="<?php echo e(route('speciality.store')); ?>" method="post" enctype="multipart/form-data">
				<?php echo csrf_field(); ?>

				<div class="row mt-5">
					<div class="col-md-3 ">
					<label>Speciality English Name</label>
				</div>
				<div class="col-md-5">
					<input type="text" name="ename" class="form-control">
				</div>
				
				</div>

				<div class="row mt-5">
					<div class="col-md-3 ">
					<label>Speciality Myanmar Name</label>
				</div>
				<div class="col-md-5">
					<input type="text" name="mname" class="form-control">
				</div>
				
				</div>


				<div class="row mt-5">
					<div class="col-md-3 ">
						<label>Hospital </label>
					</div>
					<div class="col-md-5">
						<select name="hospital" class="form-control">
							<option selected disabled>Select Hospital</option>
							<?php $__currentLoopData = $hospitals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hospital): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($hospital->id); ?>"><?php echo e($hospital->hospital_name); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
					</div>
				
				</div>

				
				<div class="row mt-5">
					<div class="col-md-3 ">
					<label>Speciality Image</label>
				</div>
				<div class="col-md-5">
					<input type="file" name="image" class="form-control">
				</div>
				
				</div>
 
				
				
				<div class="col-md-3">
					<input type="submit" value="ADD">
				</div>
			</form>	
		</div>
		<div class="edit">
			<h1> Edit speciality </h1>
			<form action="<?php echo e(route('speciality.update',1)); ?>" method="post" enctype="multipart/form-data">
				<?php echo csrf_field(); ?>
				<?php echo method_field('PUT'); ?>
				<input type="hidden" name="edit_id" id="edit_id">
				<div class="row mt-5">
					<div class="col-md-3 ">
						<label>speciality English Name</label>
					</div>
					<div class="col-md-5">
						<input type="text" name="edit_ename" class="form-control" id="edit_ename">
					</div>
				
				</div>

				<div class="row mt-5">
					<div class="col-md-3 ">
						<label>speciality Myanmar Name</label>
					</div>
					<div class="col-md-5">
						<input type="text" name="edit_mname" class="form-control" id="edit_mname">
					</div>
				
				</div>

			
				<div class="row mt-5">
					<div class="col-md-3 ">
					<label>Hospital </label>
				</div>
				<div class="col-md-5">
					<select name="edit_hospital" id="edit_hospital" class="form-control">
						<option selected disabled>Select Hospital</option>
						<?php $__currentLoopData = $hospitals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hospital): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($hospital->id); ?>"><?php echo e($hospital->hospital_name); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
				</div>
				
				</div>
				<div class="row mt-5">
					<div class="col-md-3 ">
						<label>speciality Image</label>
					</div>
					<div class="col-md-5">
						<input type="file" name="image" class="form-control">
					</div>
					<div class="col-md-4">
						<img src="" id="edit_image" width="150" height="150">
						<input type="hidden" name="old_image" id="edit_image_old">
					</div>
				
				</div>

				 
				
				<div class="col-md-3">
					<input type="submit" value="Update">
				</div>
			</form>	
		</div>

		

	<div class="col-md-12 mt-5">

		<table class="table table-dark table-sm table-responsive">
			<tr>
				<th>NO.</th>
				<th>speciality Myanmar Name</th>
				<th>speciality English Name</th>
				<th>speciality Image</th>
				<th>Hospital</th>
				 
				<th colspan="2">Action</th>
			</tr>
			<?php $i = 1; ?>
			<?php $__currentLoopData = $specialities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $speciality): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><?php echo e($i++); ?></td>
				<td><?php echo e($speciality->speciality_mname); ?></td>
				<td><?php echo e($speciality->speciality_ename); ?></td>
				<td><img src="<?php echo e($speciality->speciality_image); ?>" width="150" height="150"></td>
			 
				<td> 
				<td><?php echo e($speciality->hospital->hospital_name); ?></td>
				<td>
					<a href="#" class="btn btn-secondary  edit_item " data-id="<?php echo e($speciality->id); ?>" data-mname = "<?php echo e($speciality->speciality_mname); ?>" 
					data-image="<?php echo e($speciality->speciality_image); ?>"  
					data-ename="<?php echo e($speciality->speciality_ename); ?>" 
					data-hospital="<?php echo e($speciality->hospital_id); ?>">Edit</a>
				</td>
				<td>	
                    <form action="<?php echo e(route('speciality.destroy',$speciality->id)); ?>" method="post">
                        <?php echo method_field('Delete'); ?>
                        <?php echo csrf_field(); ?>

                        <input type="submit" name="btnsubmit" value="Delete" class="btn btn-danger">
                     </form>
                </td>
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</table>
	</div>
		
	</div>
	
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

	<script type="text/javascript">
		
		$(document).ready(function(){
			$('.add').show();
			$('.edit').hide();
			$('.edit_item').click(function(){
				$('.edit').show();
				$('.add').hide();
				var id 			 = $(this).data('id');
				var mname  		 = $(this).data('mname');
				var image 		 = $(this).data('image');
				var ename  = $(this).data('ename');
				 
				var hospital 	 = $(this).data('hospital');
			 
				console.log(id,ename,image,hospital)
				$('#edit_id').val(id);
				$('#edit_mname').val(mname);
				$('#edit_image').attr("src",image);
				$('#edit_image_old').val(image);
				$('#edit_ename').val(ename);
				$('#edit_hospital').val(hospital);
				 
			})
		})
	</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backtemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hospital_guide\resources\views/speciality/index.blade.php ENDPATH**/ ?>