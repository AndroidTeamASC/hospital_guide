<ul class="sidebar navbar-nav">
      <li class="nav-item active">
        <a class="nav-link" href="/head/dashboard">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span>
        </a>
      </li>
		<li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('department.index')); ?>">
          <i class="fas fa-fw fa-table"></i>
          <span>Department</span></a>
      </li>

      
    </ul>
<?php /**PATH C:\xampp\htdocs\lawofmyanmar\resources\views/sidebar.blade.php ENDPATH**/ ?>