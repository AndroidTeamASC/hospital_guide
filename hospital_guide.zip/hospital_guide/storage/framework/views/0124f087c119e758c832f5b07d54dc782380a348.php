
<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-md-12">
		<div class="add">
			<h1>schedule </h1>
			<?php if($errors->any()): ?>
			    <div class="alert alert-danger">
			        <ul>
			            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			                <li><?php echo e($error); ?></li>
			            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			        </ul>
			    </div>
			<?php endif; ?>
			<form action="<?php echo e(route('schedule.store')); ?>" method="post" enctype="multipart/form-data">
				<?php echo csrf_field(); ?>

				<div class="row mt-5">
					<div class="col-md-3 ">
					<label>Day</label>
				</div>
				<div class="col-md-5">
					<select name="s_day" class="form-control">
						<option disabled selected>Select Day </option>
						<?php $__currentLoopData = $days; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($day); ?>"><?php echo e($day); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
				</div>
				
				</div>

				<div class="row mt-5">
					<div class="col-md-3 ">
					<label>Time</label>
				</div>
				<div class="col-md-5">
					<input type="time" name="s_time" class="form-control">
				</div>
				
				</div>

				
				<div class="row mt-5">
					<div class="col-md-3 ">
						<label>Hospital </label>
					</div>

				<div class="col-md-5">
					<select name="hospital"  class="form-control" >
						<option selected disabled>Select Hospital</option>
						<?php $__currentLoopData = $hospitals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hospital): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($hospital->id); ?>"><?php echo e($hospital->hospital_name); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
				</div>
			</div>
				<div class="row mt-5">
					<div class="col-md-3 ">
						<label>schedule </label>
					</div>

					<div class="col-md-5">
						<select name="physician"  class="form-control" id="edit_physician">
							<option selected disabled>Select physician</option>
							<?php $__currentLoopData = $physicians; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $physician): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($physician->id); ?>"><?php echo e($physician->name); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
					</div>
				
				</div>

			  
 
				
				
				<div class="col-md-3">0
					<input type="submit" value="ADD">
				</div>
			</form>	
		</div>
		<div class="edit">
			<h1> Edit schedule </h1>
			<form action="<?php echo e(route('schedule.update',1)); ?>" method="post" enctype="multipart/form-data">
				<?php echo csrf_field(); ?>
				<?php echo method_field('PUT'); ?>
				<input type="hidden" name="edit_id" id="edit_id">
				
				<div class="row mt-5">
					<div class="col-md-3 ">
					<label>Day</label>
				</div>
				<div class="col-md-5">
					<input type="day" name="s_day" class="form-control" id="edit_day">
				</div>
				
				</div>

				<div class="row mt-5">
					<div class="col-md-3 ">
					<label>Time</label>
				</div>
				<div class="col-md-5">
					<input type="time" name="s_time" class="form-control" id="edit_time">
				</div>
				
				</div>

				
				<div class="row mt-5">
					<div class="col-md-3 ">
						<label>Hospital </label>
					</div>

				<div class="col-md-5">
					<select name="hospital"  class="form-control" id="edit_hospital">
						<option selected disabled>Select Hospital</option>
						<?php $__currentLoopData = $hospitals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hospital): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($hospital->id); ?>"><?php echo e($hospital->hospital_name); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
				</div>
			</div>
				<div class="row mt-5">
					<div class="col-md-3 ">
						<label>schedule </label>
					</div>

					<div class="col-md-5">
						<select name="physician"  class="form-control" id="edit_physician">
							<option selected disabled>Select physician</option>
							<?php $__currentLoopData = $physicians; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $physician): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($physician->id); ?>"><?php echo e($physician->name); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
					</div>
				
				</div>

			  
 
				
	

				

			  
 
				
				
				<div class="col-md-3">
					<input type="submit" value="Update">
				</div>
			</form>	
		</div>

		

	<div class="col-md-12 mt-5">

		<table class="table table-dark table-sm ">
			<tr>
				<th>NO.</th>
				<th>Day</th>
				<th>Time</th>
				<th>schedule</th>
				<th>Hospital</th>
				 
				<th colspan="2">Action</th>
			</tr>
			<?php $i = 1; ?>
			<?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><?php echo e($i++); ?></td>
				<td><?php echo e($schedule->s_day); ?></td>
				<td><?php echo e($schedule->s_time); ?></td>			 
				<td><?php echo e($schedule->hospital->hospital_name); ?></td>
				<td><?php echo e($schedule->physician->name); ?></td>
				<td>
					<a href="#" class="btn btn-secondary  edit_item " 
					data-id="<?php echo e($schedule->id); ?>" 
					data-day = "<?php echo e($schedule->s_day); ?>" 
					data-time="<?php echo e($schedule->s_time); ?>"  
					data-physician="<?php echo e($schedule->physician_id); ?>"  
					data-hospital="<?php echo e($schedule->hospital_id); ?>">Edit</a>
				</td>
				<td>	
                    <form action="<?php echo e(route('schedule.destroy',$schedule->id)); ?>" method="post">
                        <?php echo method_field('Delete'); ?>
                        <?php echo csrf_field(); ?>

                        <input type="submit" name="btnsubmit" value="Delete" class="btn btn-danger">
                     </form>
                </td>
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</table>
	</div>
		
	</div>
	
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

	<script type="text/javascript">

		
		$(document).ready(function(){

		getDays();
			$('.add').show();
			$('.edit').hide();
			$('.edit_item').click(function(){
				$('.edit').show();
				$('.add').hide();
				var id 			 = $(this).data('id');
				var day  		 = $(this).data('day');
				var time 		 = $(this).data('time');
				var physician 	 = $(this).data('physician');
				var hospital 	 = $(this).data('hospital');
			 
				console.log(id,name,hospital)
				$('#edit_id').val(id);
				$('#edit_day').val(day);
				$('#edit_time').val(time);
				$('#edit_physician').val(physician);
				$('#edit_hospital').val(hospital);
				 
			})
			function getDays(){
				var days = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
				Date.prototype.getDayName = function(){
					return days[this.getDay()];
				}

				var now = new Date();
				var day = now.getDayName();
				console.log(day);
			}
		})
	</script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('backtemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hospital_guide\resources\views/schedule/index.blade.php ENDPATH**/ ?>