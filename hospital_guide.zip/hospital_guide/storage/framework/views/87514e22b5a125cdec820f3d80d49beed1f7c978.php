
<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-md-12">
		<div class="add">
			<h1>Physician </h1>
			<?php if($errors->any()): ?>
			    <div class="alert alert-danger">
			        <ul>
			            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			                <li><?php echo e($error); ?></li>
			            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			        </ul>
			    </div>
			<?php endif; ?>
			<form action="<?php echo e(route('physician.store')); ?>" method="post" enctype="multipart/form-data">
				<?php echo csrf_field(); ?>

				<div class="row mt-5">
					<div class="col-md-3 ">
					<label>Physician Name</label>
				</div>
				<div class="col-md-5">
					<input type="text" name="name" class="form-control">
				</div>
				
				</div>

				<div class="row mt-5">
					<div class="col-md-3 ">
					<label>Degree</label>
				</div>
				<div class="col-md-5">
					<input type="text" name="degree" class="form-control">
				</div>
				
				</div>

				<div class="row mt-5">
					<div class="col-md-3 ">
						<label>Date Time </label>
					</div>
					<div class="col-md-5">
						 <input type="datetime-local" name="date_time" class="form-control">
					</div>
				
				</div>

				<div class="row mt-5">
					<div class="col-md-3 ">
						<label>Hospital </label>
					</div>

				<div class="col-md-5">
					<select name="hospital"  class="form-control">
						<option selected disabled>Select Hospital</option>
						<?php $__currentLoopData = $hospitals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hospital): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($hospital->id); ?>"><?php echo e($hospital->hospital_name); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
				</div>
			</div>
				<div class="row mt-5">
					<div class="col-md-3 ">
						<label>Speciality </label>
					</div>

					<div class="col-md-5">
						<select name="speciality"  class="form-control">
							<option selected disabled>Select Speciality</option>
							<?php $__currentLoopData = $specialities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $speciality): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($speciality->id); ?>"><?php echo e($speciality->speciality_mname); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
					</div>
				
				</div>

			  
 
				
				
				<div class="col-md-3">
					<input type="submit" value="ADD">
				</div>
			</form>	
		</div>
		<div class="edit">
			<h1> Edit physician </h1>
			<form action="<?php echo e(route('physician.update',1)); ?>" method="post" enctype="multipart/form-data">
				<?php echo csrf_field(); ?>
				<?php echo method_field('PUT'); ?>
				<input type="hidden" name="edit_id" id="edit_id">
				<div class="row mt-5">
					<div class="col-md-3 ">
					<label>Physician Name</label>
				</div>
				<div class="col-md-5">
					<input type="text" name="edit_name" class="form-control" id="edit_name">
				</div>
				
				</div>

				<div class="row mt-5">
					<div class="col-md-3 ">
					<label>Degree</label>
				</div>
				<div class="col-md-5">
					<input type="text" name="edit_degree" class="form-control"
					id="edit_degree">
				</div>
				
				</div>

				<div class="row mt-5">
					<div class="col-md-3 ">
						<label>Date Time </label>
					</div>
					<div class="col-md-5">
						 <input type="datetime-local" name="edit_date_time" class="form-control"	id="edit_date_time">
					</div>
				
				</div>

				<div class="row mt-5">
					<div class="col-md-3 ">
						<label>Hospital </label>
					</div>

					<div class="col-md-5">
						<select name="edit_hospital"  class="form-control" id="edit_hospital">
							<option selected disabled>Select Hospital</option>
							<?php $__currentLoopData = $hospitals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hospital): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($hospital->id); ?>"><?php echo e($hospital->hospital_name); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
					</div>
				</div>	
				<div class="row mt-5">
					<div class="col-md-3 ">
						<label>Speciality </label>
					</div>
					<div class="col-md-5">
						<select name="edit_speciality"  class="form-control" id="edit_speciality">
							<option selected disabled>Select Speciality</option>
							<?php $__currentLoopData = $specialities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $speciality): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($speciality->id); ?>"><?php echo e($speciality->speciality_mname); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
					</div>
				
				</div>

			  
 
				
				
				<div class="col-md-3">
					<input type="submit" value="Update">
				</div>
			</form>	
		</div>

		

	<div class="col-md-12 mt-5">

		<table class="table table-dark table-sm table-responsive">
			<tr>
				<th>NO.</th>
				<th>physician Name</th>
				<th>Degree</th>
				<th>Date Time</th>
				<th>Speciality</th>
				<th>Hospital</th>
				 
				<th colspan="2">Action</th>
			</tr>
			<?php $i = 1; ?>
			<?php $__currentLoopData = $physicians; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $physician): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><?php echo e($i++); ?></td>
				<td><?php echo e($physician->name); ?></td>
				<td><?php echo e($physician->degree); ?></td>			 
				<td><?php echo e($physician->date_time); ?></td>
				<td><?php echo e($physician->speciality->speciality_mname); ?></td>
				<td><?php echo e($physician->hospital->hospital_name); ?></td>
				<td>
					<a href="#" class="btn btn-secondary  edit_item " 
					data-id="<?php echo e($physician->id); ?>" 
					data-name = "<?php echo e($physician->name); ?>" 
					data-degree="<?php echo e($physician->degree); ?>"  
					data-date_time="<?php echo e($physician->date_time); ?>" 
					data-speciality="<?php echo e($physician->speciality_id); ?>"  
					data-hospital="<?php echo e($physician->hospital_id); ?>">Edit</a>
				</td>
				<td>	
                    <form action="<?php echo e(route('physician.destroy',$physician->id)); ?>" method="post">
                        <?php echo method_field('Delete'); ?>
                        <?php echo csrf_field(); ?>

                        <input type="submit" name="btnsubmit" value="Delete" class="btn btn-danger">
                     </form>
                </td>
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</table>
	</div>
		
	</div>
	
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

	<script type="text/javascript">
		
		$(document).ready(function(){
			$('.add').show();
			$('.edit').hide();
			$('.edit_item').click(function(){
				$('.edit').show();
				$('.add').hide();
				var id 			 = $(this).data('id');
				var name  		 = $(this).data('name');
				var degree 		 = $(this).data('degree');
				var date_time  = $(this).data('date_time');
				var speciality 		 = $(this).data('speciality');
				var hospital 	 = $(this).data('hospital');
			 
				console.log(id,name,hospital)
				$('#edit_id').val(id);
				$('#edit_name').val(name);
				$('#edit_degree').val(degree);
				$('#edit_speciality').val(speciality);
				$('#edit_date_time').val(date_time);
				$('#edit_hospital').val(hospital);
				 
			})
		})
	</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backtemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hospital_guide\resources\views/physician/index.blade.php ENDPATH**/ ?>